from django.urls import path 
from .views import index,india

urlpatterns = [
    path('',index,name = 'index'),
    path('india/',india,name = 'BBC')
]
