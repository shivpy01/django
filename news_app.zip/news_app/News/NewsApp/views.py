from django.shortcuts import render

# Create your views here.
from newsapi import NewsApiClient

def index(request):
    
    
    newsapi = NewsApiClient(api_key = 'f72faf9472b14ebc8db97ca62041d3d7')
    topheadlines = newsapi.get_everything(q = 'machinelearning')
    

 
    articles = topheadlines['articles']
 
    desc = []
    news = []
    img = []
    url = []
    for i in range(len(articles)):
        myarticles = articles[i]
 
        news.append(myarticles['title'])
        desc.append(myarticles['description'])
        img.append(myarticles['urlToImage'])
        url.append(myarticles['url'])
 
    mylist = zip(news, desc, img,url)
 
 
    return render(request, 'index.html', context={"mylist":mylist})


def india(request):
    
    
    newsapi = NewsApiClient(api_key = 'f72faf9472b14ebc8db97ca62041d3d7')
    topheadlines = newsapi.get_top_headlines(country = 'in')
      

 
    articles = topheadlines['articles']
 
    desc = []
    news = []
    img = []
    url = []
    for i in range(len(articles)):
        myarticles = articles[i]
 
        news.append(myarticles['title'])
        desc.append(myarticles['description'])
        img.append(myarticles['urlToImage'])
        url.append(myarticles['url'])
 
 
    mylist = zip(news, desc, img,url)
 
    return render(request,'india.html',context = {'mylist':mylist})
